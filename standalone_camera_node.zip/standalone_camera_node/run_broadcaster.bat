@echo off
title MMFALLDetect - Broadcasting Camera Node

echo ==============================================================
echo     Starting MMFALLDetect Broadcasting Camera Node
echo ==============================================================
echo.

:: Automatically setting the Render Backend URL (Hardcoded)
set BACKEND_URL=https://mmfalldetect.onrender.com
echo [✓] Backend Target: %BACKEND_URL%
echo.

echo [1/2] Launching Fast MJPEG Camera Server...
:: Use "start" to run it in a separate window so the script can continue
start "CV Stream Server" cmd /c "python stream_server.py & pause"

echo [2/2] Launching Ngrok Tunnel on port 8001...
echo [✓] Custom Domain: spiritual-depletion-squint.ngrok-free.dev
echo.
:: Run ngrok in this window using the specific domain
ngrok http --domain=spiritual-depletion-squint.ngrok-free.dev 8001

pause
